<template />

<script>
export default {
  name: 'CustomCharts',
  components: {
    instance: () => import('../EchartsInstance')
  },
  props: {

  },
  data() { 
    return {

    }
  }
 }
</script>

<style lang="" scoped>

</style>