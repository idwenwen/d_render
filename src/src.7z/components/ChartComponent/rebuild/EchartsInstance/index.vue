<template>
  <div
    ref="chart"
    class="charts_container"
  />
</template>

<script>
import echarts from 'echarts'
export default {
  name: '',
  props: {
    options: {
      type: Object,
      default: () => {}
    }
  },
  data() { 
    return {
      instance: '',
      currentOptions: {}
    }
  },
  watch: {
    options: {
      handler() {
        this.currentOptions = this.options
      },
      deep: true
    },
    currentOptions: {
      handler() {
        this.refresh()
        this.resize()
      }
    }
  },
  beforeMount() {
    this.echartInit()
  },
  mounted() {
    this.currentOptions = this.options
  },
  methods: {
    echartInit() {
      this.instance = echarts.init(this.$refs.chart)
    },
    refresh() {
      if (this.currentOptions.series && Object.keys(this.currentOptions.series).length !== 0) {
        this.instance.setOption(this.option)
      }
    },
    resize() {
      this.instance.resize()
    },
    getInstance() {
      return this.instance
    },
    setOptions(options) {
      this.currentOptions = options
    }
  }
}
</script>

<style lang="" scoped>

</style>