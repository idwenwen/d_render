# ComponentGroup

## 简介
  组件组内容。依据组件组内容进行数据展示以及操作。
  传递内容依据数组形式，每一项为相关组件内容的 

## props
  1. List: Array
    item - {
      type: 'form'
      props: {

      }
    }