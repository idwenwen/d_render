<script>
import basicOperation from '@/mixin/BasicOperation'
export default {
  name: 'ComponentGroup',
  components: {
    cform: () => import('../FormComponent/Group'),
    ctable: () => import('../TableComponent/PaginationTable'),
    cchart: () => import('../ChartComponent')
  },
  mixins: [
    basicOperation
  ],
  props: {
    options: {
      type: Array,
      default: () => []
    }
  },
  data() { 
    return {
      forms: []
    }
  },
  mounted() {
    for (const val of this.forms) {
      this.refOpera('comp' + val, 'setDefault')
    }
  },
  methods: {
    filterByForm(param, pos) {
      if (this.options[pos + 1].type !== 'form') {
        this.refOpera('comp' + (pos + 1), 'linkageForm', param)
      }
    },
    searchByForm(param, pos) {
      if (this.options[pos + 1].type === 'table') {
        this.refOpera('comp' + (pos + 1), 'searching', param)
      }
    },

    changeByForm(param, pos) {
      for (let o = pos + 1; o < this.options.length; o++) {
        this.refOpera('comp' + o, 'linkageChange', { param, from: 'form'})
      }
    },

    changeByTable(param, pos) {
      for (let o = pos - 1 ; o >= 0; o--) {
        this.refOpera('comp' + o, 'linkageOutside', { param, from: 'table'})
      }
    },

    children(h) {
      const child = []
      for (let i = 0; i < this.options.length; i++) {
        const val = this.options[i]
        if (val.type === 'form') {
          this.forms.push(i)
        }
        const variable = {
          props: val.props,
          ref: 'comp' + i,
          on: {
            change:(param) => {
              if (val.type === 'form') {
                this.changeForForm(param, i)
              } else {
                this.changeByTable(param, i)
              }
            }
          }
        }
        if (val.type === 'form') {
          variable.on.search = (content) => {
            this.searchByForm(content, i)
          }
          variable.on.form = (formList) => {
            this.filterByForm(formList, i)
          }
        }
        child.push(h(
          'div',{
            'class': 'comp-group__each'
          }, [h(
            'c' + val.type,
            variable
          )]
        ))
      }
    },

    groups(h) {
      return h(
        'section', {
          'class': 'cus-group__container'
        },
        this.children(h)
      )
    }
  },
  render(h) {
    return this.groups(h)
  }
 }
</script>

<style lang="" scoped>

</style>