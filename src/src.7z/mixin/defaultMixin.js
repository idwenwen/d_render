import logConsole from './logConsole'

import Vue from 'vue'

Vue.extend({
  mixins: [logConsole]
})