export default {
  API: ['metricData']
}