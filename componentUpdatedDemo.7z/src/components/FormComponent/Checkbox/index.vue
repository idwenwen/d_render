<template>
  <section>
    <el-checkbox-group v-if="Array.isArray(options)" v-model="selected">
      <c-box
        v-for="(item, index) in options"
        :key="index"
        :ref="item.value"
        :label="item.label"
        :value="item.value"
        :group="item.group || {}"
        :single="false"
        @change="boxChange(arguments, item.value)"
        @form="boxForm(arguments, item.value)"
        @search="boxSearch"
      />
    </el-checkbox-group>
    <c-box
      v-else
      :ref="options.value"
      :label="options.label"
      :value="options.value"
      :group="options.group || {}"
      @change="boxChange(arguments, options.value)"
      @form="boxForm(arguments, options.value)"
      @search="boxSearch"
    />
  </section>
</template>

<script>
import basicOperation from '@/mixin/BasicOperation'
export default {
  name: 'CusCheckbox',
  components: {
    cBox: () => import('./CheckboxSingle')
  },
  mixins: [basicOperation],
  props: {
    options: {
      // eslint-disable-next-line vue/require-prop-type-constructor
      type: Array | Object,
      default: () => []
    },
    disabled: {
      // eslint-disable-next-line vue/require-prop-type-constructor
      type: Boolean | Array,
      default: false
    }
  },
  data() {
    return {
      propResult: {},
      formResult: {},
      selected: [],
      canSend: false
    }
  },
  watch: {
    propResult: {
      handler() {
        this.change()
      },
      deep: true
    },
    formResult: {
      handler() {
        this.confirm()
      },
      deep: true
    },
    selected: {
      handler() {
        const list = this.toArr(this.options)
        for (const val of list) {
          if (this.selected.indexOf(val.value) >= 0) {
            this.refOpera(val.value, 'chooseBox')
          } else {
            this.refOpera(val.value, 'unchooseBox')
          }
        }
        this.change()
      },
      deep: true
    }
  },
  methods: {
    boxChange(res, label) {
      this.$set(this.propResult, label, res[0])
    },
    boxForm(res, label) {
      this.$set(this.formResult, label, res[0])
    },
    boxSearch(res) {
      this.$emit('search', res)
    },
    checkCanSend() {
      if (!this.canSend) {
        let canSend = true
        if (Array.isArray(this.options)) {
          for (const val of this.options) {
            if (!this.propResult[val.value]) {
              canSend = false
              break
            }
          }
        } else {
          if (!this.propResult[this.options.value]) {
            canSend = false
          }
        }
        this.canSend = canSend
      }
    },
    change() {
      this.checkCanSend()
      if (this.canSend) {
        const getProperty = () => {
          const res = []
          for (const key in this.filterBySelect(this.propResult)) {
            if (this.selected.indexOf(key) >= 0) {
              const val = this.propResult[key]
              if (Array.isArray(val)) {
                res.push(...val)
              } else {
                res.push(val)
              }
            }
          }
          return res
        }
        this.$emit('change', getProperty())
      }
    },
    confirm() {
      this.$emit('form', {
        select: this.selected,
        value: this.filterBySelect(this.formResult)
      })
    },
    filterBySelect(obj) {
      const res = {}
      for (const val of this.selected) {
        res[val] = obj[val]
      }
      return res
    },
    disable() {
      const list = this.toArr(this.options)
      for (const val of list) {
        this.refOpera(val.value, 'disable')
      }
    },
    able() {
      const list = this.toArr(this.options)
      for (const val of list) {
        this.refOpera(val.value, 'able')
      }
    },
    getParam() {
      return this.formResult
    },
    setDefault() {
      const list = this.toArr(this.options)
      this.selected = Array.isArray(this.options) ? [this.options[0].value] : []
      for (const val of list) {
        this.refOpera(val.value, 'setDefault')
        if (this.selected.indexOf(val.value) >= 0) {
          this.refOpera(val.value, 'choosedChange')
        } else {
          this.refOpera(val.value, 'boxDisable')
        }
      }
    }
  }
}
</script>

<style lang="" scoped>
</style>
