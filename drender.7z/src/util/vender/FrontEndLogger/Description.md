# Logger for Front-end

  1. Container basic type for Logger ('info', 'debug', 'warning', 'error')
  2. API for customer Error
  3. Logger saving
  4. Console current information
  5. upload it