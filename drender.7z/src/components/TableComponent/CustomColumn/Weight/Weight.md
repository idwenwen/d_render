# Weigth

## 简介
  progress 项内容，权重占比，

## props
  1. total: Number // 总值，单行权重值会从传递的单元格信息中获取
  2. showWeight: Number // 是否展示权重值。

## slot
  prepend: progress 前端自定义内容
  append: append 后端展示内容，会自动替换原有展示内容，