# Editor column

## 简介
  当前内容为预定义列，主要用于可编辑展示方面的内容。

## props
  暂无需

## slot
  prepend: 输入框外前端自定义内容
  append: 输入框外后端自定义内容
  prefix: 输入框内前端自定义内容
  suffix: 输入框内后端自定义内容