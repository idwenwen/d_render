filters:
{
  label: String,
  value: String | Array
      - [{
        label: String,
        value: String | Array
      }]
}